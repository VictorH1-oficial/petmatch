<?php

namespace src\login;

class Usuario {
    private $id :int;
    private $nome :string;
    private $email :string;
    private $senha :string;
    private $telefone :string;
 
    public function enviarMensagem(): void{

    }
    public function visualizarPet(): void{

    }
    public function cadastrar(): void{

    }
    public function editarPerfil(): void{

    }
}