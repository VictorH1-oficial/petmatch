<?php
namespace src\enderecodousuario;

class Endereco {
    private $rua :string;
    private $cidade :string;
    private $estado :string;
    private $cep :string;
}