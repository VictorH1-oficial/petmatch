<?php

namespace src\entragademensagem;

class Mensagem {
    private $id :int;
    private $conteudo :string;
    private $dataHora :string;
 
    public function enviar(): void {
    }
}