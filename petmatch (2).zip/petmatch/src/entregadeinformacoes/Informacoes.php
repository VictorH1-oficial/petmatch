<?php

namespace src\entregadeinformacoes;

class Informacoes{
    public function exibirPerfilCompleto(): void {

    }
    public function historicoMensagens(): void{

    }
    public function listarPotsDisponiveis(): void
} 
