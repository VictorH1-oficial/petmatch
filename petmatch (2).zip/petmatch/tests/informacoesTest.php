<?php
 
 namespace petmatch\tests;
use PHPUnit\Framework\TestCase;
use src\entregadeInformacoes\informacoes;
 
class InformacoesTest extends TestCase {
    public function testCriarInformacoes() {
        $info = new Informacoes();
        $this->assertInstanceOf(Informacoes::class, $info);
    }
}