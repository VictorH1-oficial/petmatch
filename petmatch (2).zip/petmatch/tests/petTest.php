<?php
 namespace petmatch\tests;
use PHPUnit\Framework\TestCase;
use src\informacoesdopet\Pet;
 
class PetTest extends TestCase {
    public function testCriarPet() {
        $pet = new Pet();
        $this->assertInstanceOf(Pet::class, $pet);
    }
}