<?php
 namespace petmatch\tests;
use PHPUnit\Framework\TestCase;
use src\login\Usuario;
 
class UsuarioTest extends TestCase {
    public function testCriarUsuario() {
        $usuario = new Usuario();
        $this->assertInstanceOf(Usuario::class, $usuario);
    }
}