<?php
 namespace petmatch\tests;
use PHPUnit\Framework\TestCase;
use src\entregademensagem\Mensagem;
 
class MensagemTest extends TestCase {
    public function testCriarMensagem() {
        $msg = new Mensagem();
        $this->assertInstanceOf(Mensagem::class, $msg);
    }
}