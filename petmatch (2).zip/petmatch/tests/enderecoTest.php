<?php
 namespace petmatch\tests;
use PHPUnit\Framework\TestCase;
use src\enderecodousuario\Endereco;
 
class enderecoTest extends TestCase {
    public function testCriarInformacoes() {
        $end = new Endereco();
        $this->assertInstanceOf(Endereco::class, $end);
    }
}